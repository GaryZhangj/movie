# Movie
### 目标任务：使用requests抓取电影网站信息和下载链接保存到数据库中，然后使用flask做数据展示。

在项目目录下运行如下命令，完成数据库迁移: <br>
python manage.py db init  <br>
python manage.py db migrate  <br>
python manage.py db upgrade  <br>
接着运行爬虫程序将数据写入MySQL，启动项目即可。 <br>
![首页](http://p9fggg4wd.bkt.clouddn.com/black.png)

