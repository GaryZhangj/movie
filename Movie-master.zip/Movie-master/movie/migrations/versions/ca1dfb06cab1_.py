"""empty message

Revision ID:


"""
from alembic import op
import sqlalchemy as sa
import pymysql
pymysql.install_as_MySQLdb()


# 版本标识符，用于用蒸馏器 .
revision = 'ca1dfb06cab1'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    # ### 自动生成的命令-请调整 ! ###
    op.create_table('dytt',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=100), nullable=False),
    sa.Column('translate_name', sa.String(length=300), nullable=False),
    sa.Column('year', sa.String(length=100), nullable=False),
    sa.Column('product_site', sa.String(length=100), nullable=False),
    sa.Column('classify', sa.String(length=100), nullable=False),
    sa.Column('actors', sa.Text(), nullable=False),
    sa.Column('content', sa.Text(), nullable=False),
    sa.Column('title', sa.String(length=500), nullable=False),
    sa.Column('cover_url', sa.String(length=500), nullable=False),
    sa.Column('screenshot_url', sa.String(length=500), nullable=False),
    sa.Column('thunder_url', sa.String(length=500), nullable=False),
    sa.Column('magnet_url', sa.String(length=500), nullable=False),
    sa.PrimaryKeyConstraint('id')
    )
    # ### 终结命令  ###


def downgrade():
    # ### 自动生成的命令###
    op.drop_table('dytt')
    # ### end Alembic commands ###
