from __future__ import with_statement
from alembic import context
from sqlalchemy import engine_from_config, pool
from logging.config import fileConfig
import logging
import pymysql
pymysql.install_as_MySQLdb()

# 这是Acbic配置对象，它提供在使用中访问.ini文件中的值。
config = context.config

#解释Python日志记录的配置文件。
# 这条线基本上建立记录器
fileConfig(config.config_file_name)
logger = logging.getLogger('alembic.env')

# 在此处添加模型的元数据对象
# 对于“自动发电”的支持
# from myapp import mymodel
# target_metadata = mymodel.Base.metadata
from flask import current_app
config.set_main_option('sqlalchemy.url',
                       current_app.config.get('SQLALCHEMY_DATABASE_URI'))
target_metadata = current_app.extensions['migrate'].db.metadata

#配置的其他值，由Env.Py的需求定义，
# 可以获得：my_important_option = config.get_main_option("my_important_option")
# ... etc.


def run_migrations_offline():
    """在“脱机”模式下运行迁移。
    这仅用URL来配置上下文。
而不是发动机，虽然发动机是可以接受的
这里也是如此。跳过引擎创建
  我们甚至不需要一个可用的DAPI。
   调用上下文。
    脚本输出。

    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(url=url)

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online():
    """
    在“联机”模式下运行迁移。

在这种情况下，我们需要创建一个引擎。
并将连接与上下文关联起来。
    """

    # 此回调用于防止自动迁移生成。
    # 当架构没有更改时
    # reference: http://alembic.zzzcomputing.com/en/latest/cookbook.html
    def process_revision_directives(context, revision, directives):
        if getattr(config.cmd_opts, 'autogenerate', False):
            script = directives[0]
            if script.upgrade_ops.is_empty():
                directives[:] = []
                logger.info('No changes in schema detected.')

    engine = engine_from_config(config.get_section(config.config_ini_section),
                                prefix='sqlalchemy.',
                                poolclass=pool.NullPool)

    connection = engine.connect()
    context.configure(connection=connection,
                      target_metadata=target_metadata,
                      process_revision_directives=process_revision_directives,
                      **current_app.extensions['migrate'].configure_args)

    try:
        with context.begin_transaction():
            context.run_migrations()
    finally:
        connection.close()

if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
